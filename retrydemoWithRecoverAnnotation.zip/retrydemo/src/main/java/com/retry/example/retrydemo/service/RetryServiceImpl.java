package com.retry.example.retrydemo.service;
import java.util.Map;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
 
@Service
public class RetryServiceImpl implements RetryService{
     
    Logger logger = LoggerFactory.getLogger(RetryServiceImpl.class);
     
    int counter = 1;
 
    @Override
    public String retry(Map<String, String> request) {
         
        logger.info("Executing retry service : "+ counter++);
        int a = 10/0;
        return "success";
    }

	@Override
	public String getRetryFallback(Map<String, String> request) {
		logger.info("Retry failed last attempt: "+ --counter);
		return "Hello from fallback method!!!";
	}
}